// NATHAN SHIRLEY (nes2ta)
export interface CommentArray {
  [comments: number]: { user: string; comment: string };
}
