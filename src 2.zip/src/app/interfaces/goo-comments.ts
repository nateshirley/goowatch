// NATHAN SHIRLEY (nes2ta)
import { CommentArray } from "./comment-array";
export interface GooComments {
  id: number;
  comments: CommentArray;
}
