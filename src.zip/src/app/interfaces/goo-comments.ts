import { CommentArray } from "./comment-array";
export interface GooComments {
  id: number;
  comments: CommentArray;
}
