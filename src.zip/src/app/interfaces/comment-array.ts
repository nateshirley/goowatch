export interface CommentArray {
  [comments: number]: { user: string; comment: string };
}
