// NATHAN SHIRLEY (nes2ta)
// comment object class, which is an array of single comments
export interface CommentArray {
  [comments: number]: { user: string; comment: string };
}
