// NATHAN SHIRLEY (nes2ta)
import { CommentArray } from "./comment-array";
// and here are the individual comments that comprise a comment array
export interface GooComments {
  id: number;
  comments: CommentArray;
}
