-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 14, 2020 at 03:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `goowatch`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `user` varchar(100) DEFAULT NULL,
  `comment` varchar(400) DEFAULT NULL,
  `guruID` int(10) DEFAULT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`user`, `comment`, `guruID`, `time`) VALUES
('yeezus', 'Money printer goes brrrrr. How?', 2, 1),
('DJtrump', 'Despite the constant negative press covfefe.', 2, 2),
('gurufollower3', 'I bought this guy\'s course for $2300. It\'s been super helpful. Set up my business and did 200k in sales.', 1, 3),
('asap', 'you\'re the man mnuchin', 2, 7),
('kobe', 'Very weak. no tenacity', 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `gurus`
--

CREATE TABLE `gurus` (
  `name` varchar(100) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `avatar` varchar(300) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gurus`
--

INSERT INTO `gurus` (`name`, `score`, `category`, `description`, `link`, `avatar`, `id`) VALUES
('Nomad Millionaire', 419, 'Amazon FBA', 'Offers advice all things Amazon FBA. A true earner on the platform. No BS; appeals particularly well to young people.', 'https://www.youtube.com/channel/UC5Dr2kj6jTNnhLzK83eVkTQ', 'https://i.imgur.com/NMgllEb.jpg', 1),
('Steven Mnuchin', 5, 'Finance', 'Steven is an American investment banker and public official who is serving as the 77th United States secretary of the treasury as part of the Cabinet of Donald Trump. Previously, Mnuchin had been a hedge fund manager and investor.', 'https://en.wikipedia.org/wiki/Steven_Mnuchin', 'https://i.imgur.com/j2mZp5G.jpg', 2),
('Jeff Nippard', 147, 'Fitness', 'Jeff Nippard is a Professional Bodybuilder who came into limelight with sharing video clips of himself on YouTube. His channel provides insight into a drug-free bodybuilding.', 'https://www.jeffnippard.com/', 'https://pbs.twimg.com/media/CjJWGBBUkAAmA3Z.jpg', 3),
('Ricky Gutierrez', 78, 'Finance', 'Ricky is a day-trader who makes videos about day trading and expensive cars. He runs a large day-trading Facebook group.', 'https://www.youtube.com/channel/UCtlAFoYl2aWb6pMiHCctQHA', 'https://www.filepicker.io/api/file/iivYEYghTxy9sq5dYW4Y', 4),
('Kinobody', 53, 'Fitness', 'The absolute sickest infomercial lifter. Will wow you with his broad shoulders and fast cars. ', 'https://kinobody.com/pages/programs', 'https://www.beyondfashionmagazine.com/wp-content/uploads/2019/09/Greg-standing-straight-1.png', 5);

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `name` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `description` varchar(280) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `user` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`name`, `category`, `description`, `link`, `number`, `user`) VALUES
('nathan', 'Software Development', '#loginForm=\"ngForm\"#loginForm=\"ngForm\"#loginForm=\"ngForm\"#loginForm=\"ngForm\"#loginForm=\"ngForm\"', 'espn.com', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `USERS`
--

CREATE TABLE `USERS` (
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `USERS`
--

INSERT INTO `USERS` (`username`, `password`) VALUES
('asap', 'rockies'),
('kobe', 'lakers');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `user` varchar(100) NOT NULL,
  `guruName` varchar(100) NOT NULL,
  `guruID` int(10) NOT NULL,
  `vote` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`user`, `guruName`, `guruID`, `vote`) VALUES
('asap', 'Nomad Millionaire', 1, 0),
('asap', 'Steven Mnuchin', 2, 1),
('asap', 'Jeff Nippard', 3, 0),
('kobe', 'Nomad Millionaire', 1, 0),
('kobe', 'Steven Mnuchin', 2, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`time`);

--
-- Indexes for table `gurus`
--
ALTER TABLE `gurus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `USERS`
--
ALTER TABLE `USERS`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`user`,`guruID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `time` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `gurus`
--
ALTER TABLE `gurus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
